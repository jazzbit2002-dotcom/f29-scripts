#!/usr/bin/env python3
"""
etf_issuer.py — 멀티에셋 ETF 순설정 추정 (P1-a1).

감리 반영:
- B-1: parser 가 as_of 를 **ISO(YYYY-MM-DD)로 변환**. 실패 시 전체 수집 FAIL.
       파싱 후 날짜 오름차순 정렬, 중복 날짜 FAIL. raw 라벨 미저장.
- B-7: lxml resolve_entities=False, no_network=True.
       recover=True 는 **명시된 제한적 예외** — 발행사 파일에 비이스케이프 '&' 실존(P0 실측)
       으로 strict 파싱이 실제 파일에서 불가하기 때문. 안전장치 = entity/network 차단 +
       Historical 시트 구조 invariant(헤더 일치·최소 행수·단조 날짜·양수 값) 미충족 시 FAIL.
       ss:Index 희소 셀 정렬 처리. --keep-file 제거(절대 ephemeral).
- 원문은 ephemeral.fetch_extract_discard(memory-only)로만 취득.
"""
from __future__ import annotations

from datetime import datetime, timezone

PARSERS: dict = {}

EXPECTED_HISTORICAL_HEADER = ["As Of", "NAV per Share", "Ex-Dividends", "Shares Outstanding"]
MIN_HISTORICAL_ROWS = 50

# bare '&' (유효 엔티티 아님) → &amp; 표적 치환용
import re as _re
_BARE_AMP = _re.compile(rb"&(?!(?:#\d+|#x[0-9a-fA-F]+|[a-zA-Z][a-zA-Z0-9]*);)")


class ParseError(Exception):
    pass


def register_parser(name):
    def deco(fn):
        PARSERS[name] = fn
        return fn
    return deco


def _iso_date(label: str) -> str:
    """'Jul 15, 2026' → '2026-07-15'. 실패 시 ParseError → 전체 수집 FAIL (B-1)."""
    try:
        return datetime.strptime(label.strip(), "%b %d, %Y").strftime("%Y-%m-%d")
    except ValueError as e:
        raise ParseError(f"날짜 ISO 변환 실패: {label!r} — 수집 FAIL") from e


SS_NS = "urn:schemas-microsoft-com:office:spreadsheet"


def _row_cells(row, ns):
    """ss:Index 희소 셀 반영해 컬럼 위치 정렬 (B-8)."""
    out = []
    for c in row.findall("ss:Cell", ns):
        idx = c.get(f"{{{SS_NS}}}Index")
        if idx:
            while len(out) < int(idx) - 1:
                out.append("")
        d = c.find("ss:Data", ns)
        out.append(d.text if d is not None and d.text else "")
    return out


@register_parser("ishares_spreadsheetml")
def parse_ishares_spreadsheetml(raw: bytes) -> list:
    """
    iShares SpreadsheetML → [{"as_of": "YYYY-MM-DD", "nav_per_share": f, "shares_outstanding": f}]
    오름차순 정렬·중복 없음 보장. invariant 미충족 시 ParseError(FAIL).
    """
    try:
        from lxml import etree
    except ImportError as e:
        raise RuntimeError("lxml 필요: pip install lxml --break-system-packages") from e

    ns = {"ss": SS_NS}
    # B-9: recover 미사용. 알려진 발행사 결함(bare '&', P0 실측)만 표적 새니타이즈한 뒤
    # **strict 파싱** — 절단·태그불일치·premature end 는 구조적으로 FAIL.
    sanitized = _BARE_AMP.sub(b"&amp;", raw)
    parser = etree.XMLParser(recover=False, resolve_entities=False,
                             no_network=True, huge_tree=False)
    try:
        root = etree.fromstring(sanitized, parser)
    except etree.XMLSyntaxError as e:
        raise ParseError(f"XML strict 파싱 실패(절단/불일치 등): {e}") from e

    # B-14: SpreadsheetML root 구조 invariant
    qn = etree.QName(root.tag)
    if qn.localname != "Workbook" or qn.namespace != SS_NS:
        raise ParseError(f"root invariant FAIL: {{{qn.namespace}}}{qn.localname} (기대: Workbook@spreadsheet ns)")

    hist_sheets = [ws for ws in root.findall(".//ss:Worksheet", ns)
                   if ws.get(f"{{{SS_NS}}}Name") == "Historical"]
    if len(hist_sheets) != 1:
        raise ParseError(f"Historical 시트 invariant FAIL: {len(hist_sheets)}개 (기대 1)")
    tables = hist_sheets[0].findall("ss:Table", ns)
    if len(tables) != 1:
        raise ParseError(f"Historical Table invariant FAIL: {len(tables)}개 (기대 1)")

    hist_rows = [_row_cells(r, ns) for r in tables[0].findall(".//ss:Row", ns)]
    if not hist_rows:
        raise ParseError("Historical 시트 없음 — invariant FAIL")

    header = [h.strip() for h in hist_rows[0][:4]]
    if header != EXPECTED_HISTORICAL_HEADER:
        raise ParseError(f"헤더 invariant FAIL: {header}")

    records = []
    for r in hist_rows[1:]:
        if len(r) < 4:
            continue  # 빈 행 허용
        as_of_label, nav_s, _exdiv, so_s = r[0], r[1], r[2], r[3]
        if not as_of_label.strip():
            continue
        iso = _iso_date(as_of_label)  # 실패 시 즉시 FAIL
        # 발행사 명시적 결측 플레이스홀더 '--' (실파일 실측: 비거래일 행) → 해당 행 skip.
        # 그 외 비수치는 결함이므로 FAIL 유지.
        if nav_s.strip() == "--" or so_s.strip() == "--":
            continue
        so_clean = so_s.replace(",", "").strip()
        try:
            nav = float(nav_s)
            so = float(so_clean)
        except ValueError as e:
            raise ParseError(f"수치 변환 실패 @ {iso}: nav={nav_s!r} so={so_s!r}") from e
        if nav <= 0 or so <= 0:
            raise ParseError(f"양수 invariant FAIL @ {iso}: nav={nav} so={so}")
        records.append({"as_of": iso, "nav_per_share": nav, "shares_outstanding": so})

    if len(records) < MIN_HISTORICAL_ROWS:
        raise ParseError(f"행수 invariant FAIL: {len(records)} < {MIN_HISTORICAL_ROWS}")

    records.sort(key=lambda x: x["as_of"])
    dates = [x["as_of"] for x in records]
    if len(dates) != len(set(dates)):
        dup = sorted({d for d in dates if dates.count(d) > 1})
        raise ParseError(f"중복 날짜 invariant FAIL: {dup[:5]}")

    return records


def compute_creation_redemption(series: list) -> list:
    """시간순 series → [{as_of(ISO), delta_shares, nav_per_share, est_creation_usd}] (첫 행 제외)."""
    out = []
    for i in range(1, len(series)):
        prev, cur = series[i - 1], series[i]
        d = cur["shares_outstanding"] - prev["shares_outstanding"]
        out.append({"as_of": cur["as_of"], "delta_shares": d,
                    "nav_per_share": cur["nav_per_share"],
                    "est_creation_usd": round(d * cur["nav_per_share"], 2)})
    return out


def assess_freshness(latest_as_of_iso: str, today, max_lag_business_days: int) -> str:
    """
    B-13: 'future' → 호출측 FAIL / 'stale' → canonical 기록·done marker 금지 / 'ok'.
    lag = (latest_as_of, today] 구간의 미국 영업일 수.
    """
    from datetime import date, timedelta
    from collectors.us_calendar import is_us_business_day
    latest = date.fromisoformat(latest_as_of_iso)
    if latest > today:
        return "future"
    lag, cur = 0, latest + timedelta(days=1)
    while cur <= today:
        if is_us_business_day(cur):
            lag += 1
        cur += timedelta(days=1)
    return "ok" if lag <= max_lag_business_days else "stale"


def poll_and_collect(ticker: str, download_url: str, parser_name: str,
                     max_lag_business_days: int = 5) -> dict:
    """
    다운로드(memory-only) → ISO 시계열 → freshness 게이트 → 순설정 계산.
    B-10: 날짜 기반 skip 없음 — NOOP/신규/revision 판정은 호출측이 digest 우선으로 수행.
    B-13: latest 가 미래면 ParseError(FAIL). 허용 lag 초과면 freshness='stale' 반환.
    """
    from datetime import datetime as _dt, timezone as _tz

    from collectors.ephemeral import fetch_extract_discard

    parser = PARSERS.get(parser_name)
    if parser is None:
        raise ValueError(f"미등록 parser: {parser_name}")

    fx = fetch_extract_discard(download_url, extractor=parser,
                               expected_prefixes=(b"<?xml",))
    series = fx["result"]
    latest_as_of = series[-1]["as_of"]  # ISO — 정렬 보장됨

    today = _dt.now(_tz.utc).date()
    fresh = assess_freshness(latest_as_of, today, max_lag_business_days)
    if fresh == "future":
        raise ParseError(f"freshness FAIL: latest_as_of={latest_as_of} 가 미래 (today={today})")

    creation = compute_creation_redemption(series)
    now = _dt.now(_tz.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return {"ticker": ticker, "parser": parser_name, "collected_at": now,
            "input_digest": fx["input_digest"],
            "persistence_mode": fx["persistence_mode"],
            "freshness": fresh,
            "series_len": len(series), "latest_as_of": latest_as_of,
            "creation_series": creation}
