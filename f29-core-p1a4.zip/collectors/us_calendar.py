#!/usr/bin/env python3
"""
us_calendar.py — 미국 증시 영업일 계산 (B-4: trade_date 정렬용).

effective_trade_date = 발행사 as_of 의 **직전 미국 영업일**.
근거: BlackRock 공시("Shares outstanding reflect positions as of the prior day")
+ P0 교차검증(우리 as_of 계산 ↔ Farside 전영업일 flow, 6/6 정합 — 주말 건너뜀 포함:
  as_of Mon Jul13 → Fri Jul10 매칭 확인).
한계 명시: 검증 창은 2026-07-07~15 (휴장일 미포함) — 휴장일 케이스는 알고리즘 처리하되
실측 대조는 다음 휴장일에 추가한다. 하드코딩된 고정 -1 이 아니라 영업일 캘린더 기반.

NYSE 휴장일을 알고리즘으로 산출(관측일 시프트: 토→금, 일→월):
  신정 / MLK(1월 3째 월) / 대통령의날(2월 3째 월) / 성금요일 / 메모리얼(5월 마지막 월)
  준틴스(6/19) / 독립기념일(7/4) / 노동절(9월 1째 월) / 추수감사절(11월 4째 목) / 성탄절(12/25)
"""
from __future__ import annotations

from datetime import date, timedelta


def _easter(year: int) -> date:
    """Anonymous Gregorian algorithm."""
    a = year % 19
    b, c = divmod(year, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month, day = divmod(h + l - 7 * m + 114, 31)
    return date(year, month, day + 1)


def _nth_weekday(year, month, weekday, n) -> date:
    """month 의 n번째 weekday(월=0). n=-1 이면 마지막."""
    if n > 0:
        d = date(year, month, 1)
        offset = (weekday - d.weekday()) % 7
        return d + timedelta(days=offset + 7 * (n - 1))
    # 마지막
    d = date(year, month + 1, 1) - timedelta(days=1) if month < 12 else date(year, 12, 31)
    offset = (d.weekday() - weekday) % 7
    return d - timedelta(days=offset)


def _observed(d: date) -> date:
    if d.weekday() == 5:  # 토 → 금
        return d - timedelta(days=1)
    if d.weekday() == 6:  # 일 → 월
        return d + timedelta(days=1)
    return d


def us_market_holidays(year: int) -> set:
    hs = {
        _observed(date(year, 1, 1)),                    # New Year
        _nth_weekday(year, 1, 0, 3),                    # MLK
        _nth_weekday(year, 2, 0, 3),                    # Presidents
        _easter(year) - timedelta(days=2),              # Good Friday
        _nth_weekday(year, 5, 0, -1),                   # Memorial
        _observed(date(year, 6, 19)),                   # Juneteenth
        _observed(date(year, 7, 4)),                    # Independence
        _nth_weekday(year, 9, 0, 1),                    # Labor
        _nth_weekday(year, 11, 3, 4),                   # Thanksgiving
        _observed(date(year, 12, 25)),                  # Christmas
    }
    return hs


_OVERRIDES_PATH = __import__("os").path.join(
    __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))),
    "config", "us_holiday_overrides.json")


def _load_overrides():
    """비정기 휴장/개장 override (B-11 권고). {"add": ["YYYY-MM-DD"], "remove": [...]}"""
    import json
    import os
    if not os.path.exists(_OVERRIDES_PATH):
        return set(), set()
    with open(_OVERRIDES_PATH, encoding="utf-8") as f:
        d = json.load(f)
    add = {date.fromisoformat(x) for x in d.get("add", [])}
    rem = {date.fromisoformat(x) for x in d.get("remove", [])}
    return add, rem


def is_us_business_day(d: date) -> bool:
    """B-11: 관측일이 이웃 연도로 넘어가는 케이스(예: 신정 토요일 → 전년 12/31 관측)를
    잡기 위해 y-1/y/y+1 세 해의 관측 휴장일을 합산 검사. override config 반영."""
    if d.weekday() >= 5:
        return False
    hols = set()
    for y in (d.year - 1, d.year, d.year + 1):
        hols |= us_market_holidays(y)
    add, rem = _load_overrides()
    hols = (hols | add) - rem
    return d not in hols


def prev_us_business_day(d: date) -> date:
    """d 의 직전 미국 영업일 (d 자신 제외)."""
    cur = d - timedelta(days=1)
    while not is_us_business_day(cur):
        cur -= timedelta(days=1)
    return cur
