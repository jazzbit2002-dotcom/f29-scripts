#!/usr/bin/env python3
"""
ephemeral.py — 전 소스 공통 취득 원칙 (절대): 필요 정보만 취득하고 즉시 폐기.

P1-a1 (감리 B-7 반영):
- 기본 경로 = **memory-only**. 임시파일을 만들지 않는다. (파일경로 요구 파서 현재 없음 —
  생기면 별도 opt-in 함수로 추가하며, 그때도 finally 삭제 강제)
- 응답 크기 상한(max_bytes) 초과 시 FAIL.
- 기대 시그니처(expected_prefixes) 불일치 시 FAIL.
- HTML/챌린지 응답(<!doctype html / <html) 즉시 FAIL — 데이터 파일 아님.
- 원문 바이트는 추출 직후 참조 해제. persistence_mode="ephemeral_memory" 기록.
"""
from __future__ import annotations

import hashlib
import urllib.error
import urllib.request

UA = {"User-Agent": "F29-Recovery-Core/1.1"}
MAX_BYTES_DEFAULT = 10 * 1024 * 1024  # 10MB (IBIT 실측 ~245KB)


class FetchError(Exception):
    pass


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def fetch_bytes(url: str, timeout: int = 30, headers: dict | None = None,
                max_bytes: int = MAX_BYTES_DEFAULT,
                expected_prefixes: tuple = None) -> bytes:
    """크기·시그니처·챌린지 가드를 통과한 원문 bytes 반환. 실패는 전부 FetchError."""
    req = urllib.request.Request(url, headers=headers or UA)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read(max_bytes + 1)
    except urllib.error.HTTPError as e:
        raise FetchError(f"HTTP {e.code}") from e
    except FetchError:
        raise
    except Exception as e:
        raise FetchError(f"{type(e).__name__}: {e}") from e

    if len(raw) > max_bytes:
        raise FetchError(f"response too large: >{max_bytes} bytes")
    head = raw.lstrip()[:64].lower()
    if head.startswith(b"<!doctype html") or head.startswith(b"<html"):
        raise FetchError("HTML/challenge response — expected data file")
    if expected_prefixes is not None and not any(raw.lstrip().startswith(p) for p in expected_prefixes):
        raise FetchError(f"unexpected signature (head={raw[:24]!r})")
    return raw


def fetch_extract_discard(url: str, extractor, timeout: int = 30,
                          headers: dict | None = None,
                          max_bytes: int = MAX_BYTES_DEFAULT,
                          expected_prefixes: tuple = None) -> dict:
    """
    memory-only: 다운로드 → extractor(raw_bytes) → 원문 참조 해제.
    디스크에 어떤 파일도 만들지 않는다.
    반환: {"result", "input_digest", "persistence_mode": "ephemeral_memory"}
    """
    raw = fetch_bytes(url, timeout=timeout, headers=headers,
                      max_bytes=max_bytes, expected_prefixes=expected_prefixes)
    digest = sha256_bytes(raw)
    try:
        result = extractor(raw)
    finally:
        raw = None  # 즉시 폐기
    return {"result": result, "input_digest": digest,
            "persistence_mode": "ephemeral_memory"}


def http_json(url: str, timeout: int = 15, headers: dict | None = None,
              max_bytes: int = MAX_BYTES_DEFAULT):
    """JSON API 용 — fetch_bytes 가드(크기·HTML 챌린지) 공유. 파싱 실패는 FetchError.
    원문 바이트 비영속. 반환: 파싱된 객체."""
    import json
    raw = fetch_bytes(url, timeout=timeout, headers=headers, max_bytes=max_bytes)
    try:
        return json.loads(raw.decode("utf-8", "replace"))
    except json.JSONDecodeError as e:
        raise FetchError(f"JSON 파싱 실패: {e}") from e
    finally:
        raw = None
