#!/usr/bin/env python3
"""
init_db.py — Recovery Core SQLite 스키마 (P1-a1, 멱등).

B-5 반영:
- etf_daily = canonical, **날짜당 1행, 최초 기록 후 값 불변** (first_seen_at 고정,
  last_seen_at 만 갱신). INSERT OR REPLACE 금지.
- etf_daily_revisions = 과거 날짜 값이 이후 파일에서 달라진 경우만 append-only 기록.
- etf_collect_log = 파일 digest 처리 이력 — 같은 digest 재실행 no-op 판정용.
비차단 반영: raw_file_deleted 고정값 → persistence_mode 실측값 저장.
B-4 반영: issuer_as_of_date / effective_trade_date 분리.
"""
import os
import sqlite3

DB = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                  "data", "recovery_core.sqlite")
os.makedirs(os.path.dirname(DB), exist_ok=True)

SCHEMA = """
CREATE TABLE IF NOT EXISTS market_candles (
  symbol TEXT NOT NULL, interval TEXT NOT NULL,
  open_time_ms INTEGER NOT NULL, close_time_ms INTEGER NOT NULL,
  open REAL, high REAL, low REAL, close REAL, volume REAL,
  taker_buy_base REAL, bar_delta REAL,
  source_id TEXT, ingested_at TEXT, input_digest TEXT,
  PRIMARY KEY (symbol, interval, open_time_ms)
);

CREATE TABLE IF NOT EXISTS derivatives_snapshots (
  market TEXT NOT NULL, observation_time TEXT NOT NULL,
  open_interest REAL, funding_rate REAL, mark_price REAL, index_price REAL, futures_volume REAL,
  source_id TEXT, ingested_at TEXT, input_digest TEXT,
  PRIMARY KEY (market, observation_time)
);

CREATE TABLE IF NOT EXISTS breadth_daily (
  symbol TEXT NOT NULL, as_of_date TEXT NOT NULL,
  close REAL, volume REAL, ma20 REAL, ma50 REAL, rs_vs_btc REAL,
  universe_version TEXT, source_id TEXT, ingested_at TEXT,
  PRIMARY KEY (symbol, as_of_date)
);

-- canonical: 날짜당 1행, 값 불변 (B-5). issuer_as_of_date = ISO (B-1).
CREATE TABLE IF NOT EXISTS etf_daily (
  asset TEXT NOT NULL, ticker TEXT NOT NULL,
  issuer_as_of_date TEXT NOT NULL,        -- ISO YYYY-MM-DD
  effective_trade_date TEXT,              -- 직전 미국 영업일 (B-4)
  delta_shares REAL, nav_per_share REAL, est_creation_usd REAL,
  source_id TEXT, input_digest TEXT,      -- 최초 관측 파일 digest (불변)
  first_seen_at TEXT, last_seen_at TEXT,
  persistence_mode TEXT,
  alignment_status TEXT DEFAULT 'provisional',  -- B-12: 증거 확정 전 provisional, effective_trade_date 는 NULL
  PRIMARY KEY (asset, ticker, issuer_as_of_date)
);

-- 과거 날짜 revision 발생 시 append-only (canonical 무접촉)
CREATE TABLE IF NOT EXISTS etf_daily_revisions (
  asset TEXT NOT NULL, ticker TEXT NOT NULL, issuer_as_of_date TEXT NOT NULL,
  delta_shares REAL, nav_per_share REAL, est_creation_usd REAL,
  source_revision_digest TEXT NOT NULL, seen_at TEXT,
  PRIMARY KEY (asset, ticker, issuer_as_of_date, source_revision_digest)
);

-- 파일 digest 처리 이력 — 동일 digest 재실행 no-op (B-5)
CREATE TABLE IF NOT EXISTS etf_collect_log (
  source_id TEXT NOT NULL, input_digest TEXT NOT NULL,
  processed_at TEXT, rows_added INTEGER, revisions_added INTEGER,
  window_date_kst TEXT, latest_as_of TEXT,
  completed INTEGER DEFAULT 0,   -- 1 = latest 전진(=marker 대상) 처리 완료 (B-15)
  PRIMARY KEY (source_id, input_digest)
);

CREATE TABLE IF NOT EXISTS feature_daily (
  as_of_date TEXT PRIMARY KEY,
  structure_state TEXT, spot_demand_state TEXT, etf_flow_state TEXT,
  derivatives_state TEXT, breadth_state TEXT, data_coverage TEXT, computed_at TEXT
);

CREATE TABLE IF NOT EXISTS evaluations (
  as_of_date TEXT NOT NULL, kind TEXT NOT NULL,
  k_state TEXT, zone INTEGER, confirmation INTEGER, data_coverage TEXT,
  template_id TEXT, evaluated_at TEXT,
  PRIMARY KEY (as_of_date, kind)
);

CREATE TABLE IF NOT EXISTS pipeline_runs (
  run_id TEXT PRIMARY KEY, started_at TEXT, finished_at TEXT,
  step TEXT, status TEXT, notes TEXT
);

CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY, value TEXT
);

DROP VIEW IF EXISTS etf_daily_resolved;
CREATE VIEW etf_daily_resolved AS
SELECT d.asset, d.ticker, d.issuer_as_of_date,
       COALESCE(r.delta_shares, d.delta_shares) AS delta_shares,
       COALESCE(r.nav_per_share, d.nav_per_share) AS nav_per_share,
       COALESCE(r.est_creation_usd, d.est_creation_usd) AS est_creation_usd,
       CASE WHEN r.issuer_as_of_date IS NULL THEN 'canonical' ELSE 'revised' END AS resolution
FROM etf_daily d
LEFT JOIN (
  SELECT asset, ticker, issuer_as_of_date, delta_shares, nav_per_share, est_creation_usd,
         ROW_NUMBER() OVER (PARTITION BY asset, ticker, issuer_as_of_date ORDER BY seen_at DESC, source_revision_digest DESC) AS rn
  FROM etf_daily_revisions
) r ON r.asset=d.asset AND r.ticker=d.ticker
   AND r.issuer_as_of_date=d.issuer_as_of_date AND r.rn=1;

CREATE TABLE IF NOT EXISTS source_health (
  source_id TEXT PRIMARY KEY,
  last_success_at TEXT, last_status TEXT, consecutive_failures INTEGER DEFAULT 0,
  kill_switch_active INTEGER DEFAULT 0, rights_status TEXT, owner_override TEXT
);
"""


SCHEMA_VERSION = "p1a3"


def main():
    con = sqlite3.connect(DB)
    con.executescript(SCHEMA)
    row = con.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
    if row and row[0] != SCHEMA_VERSION:
        raise SystemExit(f"schema_version 불일치: DB={row[0]} 코드={SCHEMA_VERSION} — migration 필요, 자동 진행 중단")
    con.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('schema_version', ?)", (SCHEMA_VERSION,))
    con.commit()
    tables = [r[0] for r in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
    con.close()
    print(f"DB: {DB}")
    print(f"테이블 {len(tables)}개: {tables}")


if __name__ == "__main__":
    main()
