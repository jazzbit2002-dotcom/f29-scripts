#!/usr/bin/env python3
"""
verify_real_file.py — relay 단계 실파일 검증 (테스트 스위트 아님).
사용: python3 scripts/verify_real_file.py /path/to/issuer_file.xls
검증: sanitize+strict 파싱 / ISO 정렬·중복0 / 순설정 행수 / freshness 평가.
원문은 읽기만 하고 이 스크립트가 저장·복사하지 않는다.
"""
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from collectors import etf_issuer as E  # noqa: E402

if len(sys.argv) != 2:
    raise SystemExit("usage: verify_real_file.py <file>")
raw = open(sys.argv[1], "rb").read()
recs = E.parse_ishares_spreadsheetml(raw)
dates = [r["as_of"] for r in recs]
assert dates == sorted(dates) and len(dates) == len(set(dates)), "정렬/중복 invariant"
creation = E.compute_creation_redemption(recs)
fresh = E.assess_freshness(dates[-1], datetime.now(timezone.utc).date(), 5)
print(f"rows={len(recs)} creation={len(creation)} range={dates[0]}..{dates[-1]} freshness={fresh}")
print("VERIFY PASS")
