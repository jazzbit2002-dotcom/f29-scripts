#!/usr/bin/env bash
# IBIT 폴링 wrapper — flock(외부) + python 내부 flock 이중.
# stdout 에 금액 없음(비차단 반영). 로그는 ledger/cron_ibit.log.
set -u
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$BASE"
mkdir -p ledger
# 로그 크기 가드 (>1MB 시 최근 512KB 만 유지)
LOG=ledger/cron_ibit.log
if [ -f "$LOG" ] && [ "$(stat -c%s "$LOG" 2>/dev/null || echo 0)" -gt 1048576 ]; then
  tail -c 524288 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
fi
python3 scripts/collect_etf_ibit.py --asset BTC --ticker IBIT >> ledger/cron_ibit.log 2>&1
