"""P1-a1 회귀 테스트 — 감리 B-8 요구 시나리오 전건."""
import json
import os
import sqlite3
import sys
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from collectors import etf_issuer as E          # noqa: E402
from collectors import ephemeral                 # noqa: E402
from collectors.us_calendar import prev_us_business_day, us_market_holidays  # noqa: E402

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _ssml(rows, sheet="Historical", header=True):
    """SpreadsheetML 합성 fixture 생성기."""
    hdr = ('<Row><Cell><Data ss:Type="String">As Of</Data></Cell>'
           '<Cell><Data ss:Type="String">NAV per Share</Data></Cell>'
           '<Cell><Data ss:Type="String">Ex-Dividends</Data></Cell>'
           '<Cell><Data ss:Type="String">Shares Outstanding</Data></Cell></Row>') if header else ''
    body = ''.join(
        f'<Row><Cell><Data ss:Type="String">{d}</Data></Cell>'
        f'<Cell><Data ss:Type="Number">{n}</Data></Cell>'
        f'<Cell><Data ss:Type="String">--</Data></Cell>'
        f'<Cell><Data ss:Type="Number">{s}</Data></Cell></Row>' for d, n, s in rows)
    return (f'<?xml version="1.0"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" '
            f'xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">'
            f'<ss:Worksheet ss:Name="{sheet}"><Table>{hdr}{body}</Table></ss:Worksheet></Workbook>'
            ).encode()


def _rows(n=60, start_so=100.0):
    """MIN_HISTORICAL_ROWS 충족용 n행."""
    out = []
    so = start_so
    for i in range(n):
        m, d = divmod(i, 28)
        out.append((f"{['Jan','Feb','Mar'][m % 3]} {d+1:02d}, 2026", 10.0, so))
        so += 1
    return out


# ── B-1: ISO 변환·연도경계·중복 ────────────────────────────────────────
def test_iso_and_year_boundary():
    rows = _rows(58) + [("Dec 31, 2025", 10.0, 500.0), ("Apr 01, 2026", 10.0, 501.0)]
    recs = E.parse_ishares_spreadsheetml(_ssml(rows))
    dates = [r["as_of"] for r in recs]
    assert dates == sorted(dates)                       # 오름차순
    assert dates[0] == "2025-12-31"                     # 연도 경계 정렬 정확
    assert all(len(d) == 10 and d[4] == "-" for d in dates)  # ISO만


def test_bad_date_fails_whole_collection():
    rows = _rows(59) + [("Foo 99, 2026", 10.0, 1.0)]
    try:
        E.parse_ishares_spreadsheetml(_ssml(rows))
        assert False
    except E.ParseError:
        pass


def test_duplicate_date_fails():
    rows = _rows(59) + [("Jan 01, 2026", 10.0, 999.0)]  # Jan 01 이미 존재
    try:
        E.parse_ishares_spreadsheetml(_ssml(rows))
        assert False
    except E.ParseError as e:
        assert "중복" in str(e)


def test_header_invariant_fails():
    bad = _ssml(_rows(60)).replace(b"NAV per Share", b"WRONG")
    try:
        E.parse_ishares_spreadsheetml(bad)
        assert False
    except E.ParseError as e:
        assert "헤더" in str(e)


def test_min_rows_invariant():
    try:
        E.parse_ishares_spreadsheetml(_ssml(_rows(10)))
        assert False
    except E.ParseError as e:
        assert "행수" in str(e)


# ── B-8: ss:Index 희소 셀 ─────────────────────────────────────────────
def test_sparse_ss_index_alignment():
    # 셀 2개 생략 후 ss:Index="4" 로 SO 만 지정 → nav 는 빈칸이어야(수치 실패 → FAIL이 정상)
    xml = ('<?xml version="1.0"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">'
           '<ss:Worksheet ss:Name="Historical"><Table>'
           '<Row><Cell><Data>As Of</Data></Cell><Cell><Data>NAV per Share</Data></Cell>'
           '<Cell><Data>Ex-Dividends</Data></Cell><Cell><Data>Shares Outstanding</Data></Cell></Row>'
           '<Row><Cell><Data>Jan 01, 2026</Data></Cell>'
           '<Cell ss:Index="4"><Data>100</Data></Cell></Row>'   # nav 자리 비움
           '</Table></ss:Worksheet></Workbook>').encode()
    try:
        E.parse_ishares_spreadsheetml(xml)
        assert False, "희소 셀로 nav 누락인데 통과하면 컬럼 오정렬"
    except E.ParseError:
        pass  # 올바르게 4번 위치로 정렬돼 nav="" → 수치 FAIL


# ── B-4: trade_date 휴장일 ────────────────────────────────────────────
def test_trade_date_weekend_and_holiday():
    assert prev_us_business_day(date(2026, 7, 13)) == date(2026, 7, 10)   # 월→금
    # 7/4 독립기념일: 2026-07-04 는 토 → 관측일 7/3(금). 7/6(월)의 직전 영업일 = 7/2(목)
    assert date(2026, 7, 3) in us_market_holidays(2026)
    assert prev_us_business_day(date(2026, 7, 6)) == date(2026, 7, 2)
    assert prev_us_business_day(date(2026, 7, 15)) == date(2026, 7, 14)   # 평일


# ── B-5: append-only ─────────────────────────────────────────────────
def _fresh_db(tmp_path):
    import scripts.init_db as I
    db = str(tmp_path / "t.sqlite")
    con = sqlite3.connect(db)
    con.executescript(I.SCHEMA)
    return con


def test_store_new_rows_only_and_digest_preserved(tmp_path):
    import scripts.collect_etf_ibit as C
    con = _fresh_db(tmp_path)
    s1 = [{"as_of": "2026-01-01", "delta_shares": 1, "nav_per_share": 10, "est_creation_usd": 10},
          {"as_of": "2026-01-02", "delta_shares": 2, "nav_per_share": 10, "est_creation_usd": 20}]
    a1, r1 = C.store_new_and_revisions(con, "BTC", "T", "src", "digestA", "ephemeral_memory", s1)
    assert (a1, r1) == (2, 0)
    # 다음 파일: 기존 2일 동일 + 신규 1일
    s2 = s1 + [{"as_of": "2026-01-03", "delta_shares": 3, "nav_per_share": 10, "est_creation_usd": 30}]
    a2, r2 = C.store_new_and_revisions(con, "BTC", "T", "src", "digestB", "ephemeral_memory", s2)
    assert (a2, r2) == (1, 0)                            # 신규만 추가
    row = con.execute("SELECT input_digest, first_seen_at FROM etf_daily WHERE issuer_as_of_date='2026-01-01'").fetchone()
    assert row[0] == "digestA"                           # 과거 행 digest 불변 (B-5)


def test_historical_revision_goes_to_revision_table(tmp_path):
    import scripts.collect_etf_ibit as C
    con = _fresh_db(tmp_path)
    s1 = [{"as_of": "2026-01-01", "delta_shares": 1, "nav_per_share": 10, "est_creation_usd": 10},
          {"as_of": "2026-01-02", "delta_shares": 2, "nav_per_share": 10, "est_creation_usd": 20}]
    C.store_new_and_revisions(con, "BTC", "T", "src", "dA", "ephemeral_memory", s1)
    s2 = [dict(s1[0], est_creation_usd=99.0, delta_shares=9.9), s1[1]]   # 과거값 변경
    a, r = C.store_new_and_revisions(con, "BTC", "T", "src", "dB", "ephemeral_memory", s2)
    assert (a, r) == (0, 1)
    canon = con.execute("SELECT est_creation_usd FROM etf_daily WHERE issuer_as_of_date='2026-01-01'").fetchone()[0]
    assert canon == 10                                    # canonical 무접촉
    rev = con.execute("SELECT est_creation_usd, source_revision_digest FROM etf_daily_revisions").fetchone()
    assert rev == (99.0, "dB")                            # revision append


# ── B-2: done marker / flock ─────────────────────────────────────────
def test_done_marker_blocks_network(tmp_path, monkeypatch):
    import scripts.collect_etf_ibit as C
    monkeypatch.setattr(C, "LEDGER", str(tmp_path))
    monkeypatch.setattr(C, "DONE_MARKER", str(tmp_path / "done.json"))
    monkeypatch.setattr(C, "LOCKFILE", str(tmp_path / ".lock"))
    window = C._kst_window_date()
    C._write_done(window, "2026-07-15", "2026-07-15", "d")
    # 네트워크가 불리면 실패하도록
    def boom(*a, **k):
        raise AssertionError("done marker 인데 네트워크 호출됨 (B-2 위반)")
    monkeypatch.setattr(E, "poll_and_collect", boom)
    assert C.main("BTC", "IBIT") == 0                     # 호출 전 종료


def test_flock_blocks_second_process(tmp_path):
    import fcntl
    lf = str(tmp_path / ".lock")
    f1 = open(lf, "w"); fcntl.flock(f1, fcntl.LOCK_EX | fcntl.LOCK_NB)
    f2 = open(lf, "w")
    try:
        fcntl.flock(f2, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert False, "두 번째 flock 이 성공하면 안 됨"
    except BlockingIOError:
        pass
    finally:
        f1.close(); f2.close()


# ── B-6: kill switch ─────────────────────────────────────────────────
def test_kill_switch_active_stops(tmp_path, monkeypatch):
    import scripts.collect_etf_ibit as C
    reg = {"assets": {"BTC": {"enabled": True, "issuers": {"IBIT": {
        "enabled": True, "kill_switch_active": True,
        "download_url": "http://x", "parser": "ishares_spreadsheetml"}}}}}
    p = tmp_path / "reg.json"; p.write_text(json.dumps(reg))
    monkeypatch.setattr(C, "REGISTRY", str(p))
    monkeypatch.setattr(C, "LEDGER", str(tmp_path))
    monkeypatch.setattr(C, "DONE_MARKER", str(tmp_path / "done.json"))
    monkeypatch.setattr(C, "LOCKFILE", str(tmp_path / ".lock"))
    def boom(*a, **k):
        raise AssertionError("kill_switch_active 인데 네트워크 호출")
    monkeypatch.setattr(E, "poll_and_collect", boom)
    assert C.main("BTC", "IBIT") == 0


# ── B-7: 응답 가드 ────────────────────────────────────────────────────
class _FakeResp:
    def __init__(self, data): self.data = data; self.headers = {}
    def read(self, n=-1): return self.data if n < 0 else self.data[:n]
    def __enter__(self): return self
    def __exit__(self, *a): pass


def test_oversized_response_fails(monkeypatch):
    import urllib.request
    monkeypatch.setattr(urllib.request, "urlopen",
                        lambda req, timeout=30: _FakeResp(b"x" * 2048))
    try:
        ephemeral.fetch_bytes("http://x", max_bytes=1024)
        assert False
    except ephemeral.FetchError as e:
        assert "too large" in str(e)


def test_html_challenge_fails(monkeypatch):
    import urllib.request
    monkeypatch.setattr(urllib.request, "urlopen",
                        lambda req, timeout=30: _FakeResp(b"<!DOCTYPE html><html>captcha</html>"))
    try:
        ephemeral.fetch_bytes("http://x")
        assert False
    except ephemeral.FetchError as e:
        assert "challenge" in str(e).lower() or "HTML" in str(e)


def test_signature_mismatch_fails(monkeypatch):
    import urllib.request
    monkeypatch.setattr(urllib.request, "urlopen",
                        lambda req, timeout=30: _FakeResp(b"PK\x03\x04zipdata"))
    try:
        ephemeral.fetch_bytes("http://x", expected_prefixes=(b"<?xml",))
        assert False
    except ephemeral.FetchError:
        pass


def test_memory_only_no_files(monkeypatch, tmp_path):
    import glob
    import urllib.request
    before = set(glob.glob("/tmp/f29core_*"))
    monkeypatch.setattr(urllib.request, "urlopen",
                        lambda req, timeout=30: _FakeResp(b"<?xml ok"))
    r = ephemeral.fetch_extract_discard("http://x", extractor=lambda b: len(b),
                                        expected_prefixes=(b"<?xml",))
    assert r["persistence_mode"] == "ephemeral_memory"
    assert set(glob.glob("/tmp/f29core_*")) == before     # 파일 0


# ── cron wrapper smoke ────────────────────────────────────────────────
def test_cron_wrapper_syntax():
    import subprocess
    rc = subprocess.call(["bash", "-n", os.path.join(BASE, "scripts", "cron_ibit.sh")])
    assert rc == 0


if __name__ == "__main__":
    import subprocess
    raise SystemExit(subprocess.call([sys.executable, "-m", "pytest", __file__, "-v"]))

# ── B-9: XML 손상 반례 (sanitize+strict) ──────────────────────────────
def test_truncated_xml_fails():
    good = _ssml(_rows(60))
    try:
        E.parse_ishares_spreadsheetml(good[:-40])
        assert False, "절단 파일이 통과하면 안 됨"
    except E.ParseError as e:
        assert "strict" in str(e)


def test_mismatched_closing_tag_fails():
    bad = _ssml(_rows(60)).replace(b"</ss:Worksheet>", b"</WrongTag>", 1)
    assert bad != _ssml(_rows(60))
    try:
        E.parse_ishares_spreadsheetml(bad)
        assert False
    except E.ParseError as e:
        assert "strict" in str(e)


def test_known_bare_ampersand_passes():
    # Data 텍스트에 bare & — 발행사 실파일 결함 유형. 표적 새니타이즈로 통과해야.
    xml = _ssml(_rows(60)).replace(
        b"<Data ss:Type=\"String\">--</Data>",
        b"<Data ss:Type=\"String\">A & B</Data>", 1)
    recs = E.parse_ishares_spreadsheetml(xml)
    assert len(recs) == 60


# ── B-10: 같은 latest + 다른 digest → 과거 revision 감지 (스크립트 흐름) ──
def _script_env(tmp_path, monkeypatch):
    import scripts.collect_etf_ibit as C
    import scripts.init_db as I
    db = str(tmp_path / "t.sqlite")
    con = sqlite3.connect(db)
    con.executescript(I.SCHEMA)
    con.close()
    reg = {"assets": {"BTC": {"enabled": True, "issuers": {"IBIT": {
        "enabled": True, "kill_switch_active": False,
        "download_url": "http://mock", "parser": "ishares_spreadsheetml"}}}},
        "freshness": {"max_lag_business_days": 5}}
    rp = tmp_path / "reg.json"; rp.write_text(json.dumps(reg))
    monkeypatch.setattr(C, "DB", db)
    monkeypatch.setattr(C, "REGISTRY", str(rp))
    monkeypatch.setattr(C, "LEDGER", str(tmp_path))
    monkeypatch.setattr(C, "DONE_MARKER", str(tmp_path / "done.json"))
    monkeypatch.setattr(C, "LOCKFILE", str(tmp_path / ".lock"))
    monkeypatch.setattr(C, "FIRST_SEEN_LOG", str(tmp_path / "fs.log"))
    return C, db


def test_same_latest_different_digest_records_revision(tmp_path, monkeypatch):
    C, db = _script_env(tmp_path, monkeypatch)
    base = [{"as_of": "2026-07-14", "delta_shares": 1.0, "nav_per_share": 10.0, "est_creation_usd": 10.0},
            {"as_of": "2026-07-15", "delta_shares": 2.0, "nav_per_share": 10.0, "est_creation_usd": 20.0}]

    def make_poll(creation, digest):
        def _p(*a, **k):
            return {"input_digest": digest, "persistence_mode": "ephemeral_memory",
                    "freshness": "ok", "latest_as_of": creation[-1]["as_of"],
                    "series_len": len(creation) + 1, "creation_series": creation}
        return _p

    windows = iter(["2026-07-16", "2026-07-17", "2026-07-18"])
    monkeypatch.setattr(C, "_kst_window_date", lambda now_utc=None: next(windows))

    # run1: digestA → 신규 2행 + done marker(W1)
    monkeypatch.setattr(E, "poll_and_collect", make_poll(base, "digestA"))
    assert C.main("BTC", "IBIT") == 0
    con = sqlite3.connect(db)
    assert con.execute("SELECT COUNT(*) FROM etf_daily").fetchone()[0] == 2
    marker = json.loads(open(str(tmp_path / "done.json")).read())
    assert marker["window_date_kst"] == "2026-07-16"
    assert marker["expected_issuer_as_of"] == "2026-07-15"

    # run2(W2): 같은 digestA → 완전 NOOP (target 07-16 미달 → marker 미갱신)
    monkeypatch.setattr(E, "poll_and_collect", make_poll(base, "digestA"))
    assert C.main("BTC", "IBIT") == 0
    assert con.execute("SELECT COUNT(*) FROM etf_daily").fetchone()[0] == 2
    assert con.execute("SELECT COUNT(*) FROM etf_daily_revisions").fetchone()[0] == 0

    # run3(W3): 같은 latest + 다른 digestB + 과거값 정정 → revision 기록, canonical 불변,
    #           done marker 는 W1 그대로(latest 미전진)
    revised = [dict(base[0], est_creation_usd=99.0, delta_shares=9.9), base[1]]
    monkeypatch.setattr(E, "poll_and_collect", make_poll(revised, "digestB"))
    assert C.main("BTC", "IBIT") == 0
    assert con.execute("SELECT COUNT(*) FROM etf_daily_revisions").fetchone()[0] == 1
    canon = con.execute("SELECT est_creation_usd FROM etf_daily WHERE issuer_as_of_date='2026-07-14'").fetchone()[0]
    assert canon == 10.0
    marker = json.loads(open(str(tmp_path / "done.json")).read())
    assert marker["window_date_kst"] == "2026-07-16"  # target 미달 fresh digest 는 marker 미갱신
    con.close()


# ── B-11: 휴장일 연도 경계 회귀 ───────────────────────────────────────
def test_holiday_year_boundary_regression():
    from collectors.us_calendar import is_us_business_day
    assert not is_us_business_day(date(2021, 12, 31))   # 2022 신정(토) 관측
    assert not is_us_business_day(date(2027, 12, 31))   # 2028 신정(토) 관측
    assert prev_us_business_day(date(2022, 1, 3)) == date(2021, 12, 30)


# ── B-13: freshness 게이트 ────────────────────────────────────────────
def test_freshness_future_fails_and_stale_detected():
    today = date(2026, 7, 16)
    try:
        # 미래 → poll 내부에서 ParseError. assess 단위로는 'future'
        assert E.assess_freshness("2026-07-20", today, 5) == "future"
    except Exception:
        assert False
    assert E.assess_freshness("2026-07-15", today, 5) == "ok"
    # 10 영업일 이상 지연 → stale
    assert E.assess_freshness("2026-06-25", today, 5) == "stale"


def test_stale_blocks_canonical_and_marker(tmp_path, monkeypatch):
    C, db = _script_env(tmp_path, monkeypatch)
    monkeypatch.setattr(C, "_kst_window_date", lambda now_utc=None: "2026-07-16")

    def stale_poll(*a, **k):
        return {"input_digest": "dS", "persistence_mode": "ephemeral_memory",
                "freshness": "stale", "latest_as_of": "2026-06-01",
                "series_len": 60, "creation_series": [
                    {"as_of": "2026-06-01", "delta_shares": 1, "nav_per_share": 1, "est_creation_usd": 1}]}
    monkeypatch.setattr(E, "poll_and_collect", stale_poll)
    assert C.main("BTC", "IBIT") == 0
    con = sqlite3.connect(db)
    assert con.execute("SELECT COUNT(*) FROM etf_daily").fetchone()[0] == 0   # canonical 기록 금지
    assert not os.path.exists(str(tmp_path / "done.json"))                     # marker 금지
    con.close()

# ── B-14: root 구조 invariant ─────────────────────────────────────────
def test_wrong_root_fails():
    bad = _ssml(_rows(60)).replace(b"<Workbook ", b"<Foo ", 1).replace(b"</Workbook>", b"</Foo>", 1)
    try:
        E.parse_ishares_spreadsheetml(bad)
        assert False, "root=Foo 인데 통과"
    except E.ParseError as e:
        assert "root invariant" in str(e)


def test_wrong_namespace_fails():
    bad = _ssml(_rows(60)).replace(b"urn:schemas-microsoft-com:office:spreadsheet",
                                   b"urn:wrong-namespace")
    try:
        E.parse_ishares_spreadsheetml(bad)
        assert False
    except E.ParseError as e:
        assert "invariant" in str(e)


def test_duplicate_historical_fails():
    one = _ssml(_rows(60))
    # Worksheet 블록 복제
    start = one.index(b"<ss:Worksheet")
    end = one.index(b"</ss:Worksheet>") + len(b"</ss:Worksheet>")
    dup = one[:end] + one[start:end] + one[end:]
    try:
        E.parse_ishares_spreadsheetml(dup)
        assert False
    except E.ParseError as e:
        assert "Historical 시트 invariant" in str(e)


def test_missing_table_fails():
    bad = _ssml(_rows(60)).replace(b"<Table>", b"<NotTable>").replace(b"</Table>", b"</NotTable>")
    try:
        E.parse_ishares_spreadsheetml(bad)
        assert False
    except E.ParseError as e:
        assert "Table invariant" in str(e)


# ── B-15: done marker 유실 복구 ───────────────────────────────────────
def test_marker_loss_recovered_same_window(tmp_path, monkeypatch):
    C, db = _script_env(tmp_path, monkeypatch)
    base = [{"as_of": "2026-07-14", "delta_shares": 1.0, "nav_per_share": 10.0, "est_creation_usd": 10.0},
            {"as_of": "2026-07-15", "delta_shares": 2.0, "nav_per_share": 10.0, "est_creation_usd": 20.0}]

    def poll(*a, **k):
        return {"input_digest": "digestX", "persistence_mode": "ephemeral_memory",
                "freshness": "ok", "latest_as_of": "2026-07-15",
                "series_len": 3, "creation_series": base}
    monkeypatch.setattr(E, "poll_and_collect", poll)
    monkeypatch.setattr(C, "_kst_window_date", lambda now_utc=None: "2026-07-16")

    # run1: DB 저장 성공 직후 marker 작성이 죽는 crash 시뮬레이션 (target 07-15 도달 상태)
    real_write = C._write_done
    def crash_write(*a, **k):
        raise OSError("simulated crash before marker")
    monkeypatch.setattr(C, "_write_done", crash_write)
    try:
        C.main("BTC", "IBIT")
        assert False, "crash 가 전파돼야 함"
    except OSError:
        pass
    con = sqlite3.connect(db)
    assert con.execute("SELECT COUNT(*) FROM etf_daily").fetchone()[0] == 2       # DB 는 성공
    assert con.execute("SELECT completed FROM etf_collect_log").fetchone()[0] == 1
    assert not os.path.exists(str(tmp_path / "done.json"))                         # marker 유실

    # run2 (같은 창 W1, 같은 digest): NOOP + marker 복구 → 이후 네트워크 차단 가능
    monkeypatch.setattr(C, "_write_done", real_write)
    assert C.main("BTC", "IBIT") == 0
    marker = json.loads(open(str(tmp_path / "done.json")).read())
    assert marker["window_date_kst"] == "2026-07-16" and marker["as_of"] == "2026-07-15"
    assert marker["expected_issuer_as_of"] == "2026-07-15"

    # run3 (같은 창): marker 가 네트워크 호출 전 차단
    def boom(*a, **k):
        raise AssertionError("marker 복구 후에도 네트워크 호출됨")
    monkeypatch.setattr(E, "poll_and_collect", boom)
    assert C.main("BTC", "IBIT") == 0
    con.close()


def test_prev_window_digest_does_not_create_marker(tmp_path, monkeypatch):
    C, db = _script_env(tmp_path, monkeypatch)
    con = sqlite3.connect(db)
    # 전일(W0) 창에서 완료된 digest 를 로그에 심어둠
    con.execute("INSERT INTO etf_collect_log (source_id, input_digest, processed_at, rows_added, "
                "revisions_added, window_date_kst, latest_as_of, completed) VALUES "
                "('etf_issuer_ibit','digestOld','t',2,0,'2026-07-15','2026-07-14',1)")
    con.commit(); con.close()

    def poll(*a, **k):  # 오늘 창에서 같은 파일(전일 데이터) 재수신
        return {"input_digest": "digestOld", "persistence_mode": "ephemeral_memory",
                "freshness": "ok", "latest_as_of": "2026-07-14",
                "series_len": 3, "creation_series": [
                    {"as_of": "2026-07-14", "delta_shares": 1, "nav_per_share": 10, "est_creation_usd": 10}]}
    monkeypatch.setattr(E, "poll_and_collect", poll)
    monkeypatch.setattr(C, "_kst_window_date", lambda now_utc=None: "2026-07-16")
    assert C.main("BTC", "IBIT") == 0
    # B-16 test4: target(07-15) 미달(07-14) 전일 digest → marker 금지, 폴링 계속
    assert not os.path.exists(str(tmp_path / "done.json"))

# ── B-16: 완료 조건 = 오늘 목표 도달 ──────────────────────────────────
def _poll_of(creation, digest):
    def _p(*a, **k):
        return {"input_digest": digest, "persistence_mode": "ephemeral_memory",
                "freshness": "ok", "latest_as_of": creation[-1]["as_of"],
                "series_len": len(creation) + 1, "creation_series": creation}
    return _p


def test_b16_lagging_file_below_target_no_marker_then_target_file_marks(tmp_path, monkeypatch):
    """감리 test1+2: DB 뒤처짐 + target 전 파일 → 저장하되 marker 없음·폴링 계속.
    같은 창에서 target 파일 도착 → marker 작성. first_seen 은 target 도달 시 1회(test6)."""
    C, db = _script_env(tmp_path, monkeypatch)
    monkeypatch.setattr(C, "_kst_window_date", lambda now_utc=None: "2026-07-17")  # 금 → target 07-16

    below = [{"as_of": "2026-07-14", "delta_shares": 1, "nav_per_share": 10, "est_creation_usd": 10},
             {"as_of": "2026-07-15", "delta_shares": 2, "nav_per_share": 10, "est_creation_usd": 20}]
    monkeypatch.setattr(E, "poll_and_collect", _poll_of(below, "digLag"))
    assert C.main("BTC", "IBIT") == 0
    con = sqlite3.connect(db)
    assert con.execute("SELECT COUNT(*) FROM etf_daily").fetchone()[0] == 2   # 데이터는 저장
    assert not os.path.exists(str(tmp_path / "done.json"))                     # marker 금지 (test1)
    assert not os.path.exists(str(tmp_path / "fs.log"))                        # first_seen 도 미기록

    target = below + [{"as_of": "2026-07-16", "delta_shares": 3, "nav_per_share": 10, "est_creation_usd": 30}]
    monkeypatch.setattr(E, "poll_and_collect", _poll_of(target, "digTarget"))
    assert C.main("BTC", "IBIT") == 0
    marker = json.loads(open(str(tmp_path / "done.json")).read())
    assert marker["expected_issuer_as_of"] == "2026-07-16" and marker["as_of"] == "2026-07-16"  # test2
    fs = open(str(tmp_path / "fs.log")).read().strip().splitlines()
    assert len(fs) == 1 and "as_of=2026-07-16" in fs[0]                        # test6: 1회만
    con.close()


def test_b16_holiday_same_digest_marks_current_window(tmp_path, monkeypatch):
    """감리 test3: 미국 휴장일 — 전일 창 digest 라도 target 충족이면 오늘 marker.
    2026-07-04(토, KST) 창: 07-03 관측휴장 → expected 07-02."""
    C, db = _script_env(tmp_path, monkeypatch)
    con = sqlite3.connect(db)
    con.execute("INSERT INTO etf_collect_log (source_id, input_digest, processed_at, rows_added, "
                "revisions_added, window_date_kst, latest_as_of, completed) VALUES "
                "('etf_issuer_ibit','digHol','t',1,0,'2026-07-03','2026-07-02',1)")
    con.commit(); con.close()

    creation = [{"as_of": "2026-07-02", "delta_shares": 1, "nav_per_share": 10, "est_creation_usd": 10}]
    monkeypatch.setattr(E, "poll_and_collect", _poll_of(creation, "digHol"))
    monkeypatch.setattr(C, "_kst_window_date", lambda now_utc=None: "2026-07-04")
    assert C.main("BTC", "IBIT") == 0
    marker = json.loads(open(str(tmp_path / "done.json")).read())
    assert marker["window_date_kst"] == "2026-07-04"
    assert marker["expected_issuer_as_of"] == "2026-07-02"                     # 휴장 반영 target
    assert not os.path.exists(str(tmp_path / "fs.log"))                        # 중복 first_seen 금지

    # marker 가 이후 실행을 네트워크 전 차단
    def boom(*a, **k):
        raise AssertionError("휴장일 marker 후에도 네트워크 호출")
    monkeypatch.setattr(E, "poll_and_collect", boom)
    assert C.main("BTC", "IBIT") == 0


def test_b16_crash_before_collect_log_recovers_marker(tmp_path, monkeypatch):
    """감리 test5: DB commit 후 collect_log 이전 crash → 재실행이 멱등 재저장 후
    target 충족 시 marker 작성 (구 advanced 로직에선 불가능했던 케이스)."""
    C, db = _script_env(tmp_path, monkeypatch)
    creation = [{"as_of": "2026-07-14", "delta_shares": 1, "nav_per_share": 10, "est_creation_usd": 10},
                {"as_of": "2026-07-15", "delta_shares": 2, "nav_per_share": 10, "est_creation_usd": 20}]
    # crash 상태 재현: canonical 은 이미 저장됨 / collect_log 비어 있음 / marker 없음
    con = sqlite3.connect(db)
    import scripts.collect_etf_ibit as CC
    CC.store_new_and_revisions(con, "BTC", "IBIT", "etf_issuer_ibit",
                               "digCrash", "ephemeral_memory", creation)
    con.close()

    monkeypatch.setattr(E, "poll_and_collect", _poll_of(creation, "digCrash"))
    monkeypatch.setattr(C, "_kst_window_date", lambda now_utc=None: "2026-07-16")  # target 07-15
    assert C.main("BTC", "IBIT") == 0
    marker = json.loads(open(str(tmp_path / "done.json")).read())
    assert marker["as_of"] == "2026-07-15"                                     # 복구 완료
    con = sqlite3.connect(db)
    assert con.execute("SELECT COUNT(*) FROM etf_daily").fetchone()[0] == 2    # 멱등(중복 없음)
    assert con.execute("SELECT completed FROM etf_collect_log").fetchone()[0] == 1
    con.close()
